<?php
  define('MAILHOST', "smtp@gmail.com");
  define('USERNAME', "arka.brian13@gmail.com");
  define('PASSWORD', "wrqn raqa ijwp qmsi");
  define('SEND_FROM', "uifessng@gmail.com");
  define('SEND_FROM_NAME', "AKUN UI SI ARKA");
  define('REPLY_TO', "uifessng@gmail.com");
  define('REPLY_TO_NAME', "AKUNNYA ARKA DI UI");
?>