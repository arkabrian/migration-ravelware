import './bootstrap';
import './libs/trix';
